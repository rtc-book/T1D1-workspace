/* Lab <number> - <your name> */

/* includes */
#include <stdio.h>
#include <string.h>
#include "MyRio.h"
#include "T1.h"

/* prototypes */

/* definitions */

int main(int argc, char **argv)
{
	/* front matter */
	NiFpga_Status status;
    status = MyRio_Open();		    	/* open myRIO NiFpga session */
    if (MyRio_IsNotSuccess(status)) return status;

    /* main matter */
    printf("Hello World!\n");			/* print to console */
    printf_lcd("\fHello World!\n");		/* print to display */

    /* end matter */
	status = MyRio_Close();				/* close myRIO NiFpga session */
	return status;
}
