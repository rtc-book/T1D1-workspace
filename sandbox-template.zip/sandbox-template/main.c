/*
 * sandbox-template.c
 * A local template for running C program on development computer.
 */

/* includes */
#include <stdio.h> 				/* standard io library (printf) */
#include <stdlib.h> 			/* standard library (EXIT_SUCCESS) */

/* prototypes */

/* function definitions */
	int							/* success/error code */
main(void)
{
	puts("Hello World!"); 		/* print to console */
	return EXIT_SUCCESS;		/* return EXIT_SUCCESS symbolic constant */
}
